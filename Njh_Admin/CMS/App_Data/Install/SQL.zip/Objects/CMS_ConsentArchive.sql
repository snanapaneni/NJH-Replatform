SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_ConsentArchive](
	[ConsentArchiveID] [int] IDENTITY(1,1) NOT NULL,
	[ConsentArchiveGuid] [uniqueidentifier] NOT NULL,
	[ConsentArchiveLastModified] [datetime2](7) NOT NULL,
	[ConsentArchiveConsentID] [int] NOT NULL,
	[ConsentArchiveHash] [nvarchar](100) NOT NULL,
	[ConsentArchiveContent] [nvarchar](max) NOT NULL,
 CONSTRAINT [PK_CMS_ConsentArchive] PRIMARY KEY CLUSTERED 
(
	[ConsentArchiveID] ASC
)
)
GO
CREATE NONCLUSTERED INDEX [IX_ConsentArchive_ConsentArchiveConsentID] ON [dbo].[CMS_ConsentArchive]
(
	[ConsentArchiveConsentID] ASC
)
GO
ALTER TABLE [dbo].[CMS_ConsentArchive] ADD  CONSTRAINT [DEFAULT_CMS_ConsentArchive_ConsentArchiveGuid]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [ConsentArchiveGuid]
GO
ALTER TABLE [dbo].[CMS_ConsentArchive] ADD  CONSTRAINT [DEFAULT_CMS_ConsentArchive_ConsentArchiveLastModified]  DEFAULT ('1/1/0001 12:00:00 AM') FOR [ConsentArchiveLastModified]
GO
ALTER TABLE [dbo].[CMS_ConsentArchive] ADD  CONSTRAINT [DEFAULT_CMS_ConsentArchive_ConsentArchiveConsentID]  DEFAULT ((0)) FOR [ConsentArchiveConsentID]
GO
ALTER TABLE [dbo].[CMS_ConsentArchive] ADD  CONSTRAINT [DEFAULT_CMS_ConsentArchive_ConsentArchiveHash]  DEFAULT (N'') FOR [ConsentArchiveHash]
GO
ALTER TABLE [dbo].[CMS_ConsentArchive] ADD  CONSTRAINT [DEFAULT_CMS_ConsentArchive_ConsentArchiveContent]  DEFAULT (N'') FOR [ConsentArchiveContent]
GO
ALTER TABLE [dbo].[CMS_ConsentArchive]  WITH CHECK ADD  CONSTRAINT [FK_CMS_ConsentArchive_ConsentArchiveConsentID_CMS_Consent] FOREIGN KEY([ConsentArchiveConsentID])
REFERENCES [dbo].[CMS_Consent] ([ConsentID])
GO
ALTER TABLE [dbo].[CMS_ConsentArchive] CHECK CONSTRAINT [FK_CMS_ConsentArchive_ConsentArchiveConsentID_CMS_Consent]
GO
