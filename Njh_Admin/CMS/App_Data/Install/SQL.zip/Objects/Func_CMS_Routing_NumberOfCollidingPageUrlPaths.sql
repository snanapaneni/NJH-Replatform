SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION Func_CMS_Routing_NumberOfCollidingPageUrlPaths(@path nvarchar(450), @siteId int)
RETURNS int
AS 
BEGIN
	DECLARE @rowcount int
	SELECT @rowcount = COUNT(*) 
		FROM CMS_PageUrlPath 
		WHERE PageUrlPathUrlPathHash = CONVERT(NVARCHAR(64), HASHBYTES('SHA2_256', LOWER(@path)), 2) AND PageUrlPathSiteID = @siteId
	RETURN @rowcount
END;
GO
